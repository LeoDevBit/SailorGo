#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <chrono>
#include <windows.h>
#include <thread> // For std::this_thread and std::chrono

using namespace std;

void clearScreen()
{
    system("cls");
}

void simulateLoading()
{
    cout << "Connecting";
    for (int i = 0; i < 5; ++i)
    {
        Sleep(1000);
        cout << ".";
        cout.flush();
    }
    cout << endl;
}

void startServerStep()
{
    char choice;
    cout << "\033[40;40;40m\033[1;32m";
    cout << "Do you want to start the server? (y/n): ";
    cout << "\033[0m";
    cin >> choice;
    if (choice == 'y' || choice == 'Y')
    {
        cout << "Starting server..." << endl;
        Sleep(1000);
        cout << "Please wait. Loading files..." << endl;
        Sleep(1500);
    }
    else
    {
        cout << "Server not started." << endl;
        exit(0); // Exit if the user does not want to start the server
    }
}

void enterCredentialsStep()
{
    clearScreen();
    string username, password;

    cout << "\033[48;2;255;215;95m\033[30m";
    cout << "Enter your Actual Name and Password";
    cout << "\033[0m";
    cout << endl
         << "Enter Your"<< "\033[32m" << " First " << "\033[0m" << "Name only: ";
    cin >> username;
    cout << "Enter a Password: ";
    cin >> password;

    // Store username in data.txt and clear the file before writing
    ofstream outFile("VirtualBrowser/data.html", ios::trunc); // ios::trunc clears the file
    if (outFile.is_open())
    {
        outFile << " <body style=\"font-size: 30px; font-family: 'Segoe UI'; font-weight: 500; color: #d56676\"> \n";    // Write "hello" as pre-text
        outFile << username << "\n"; // Write the username
        outFile << "</body>";       // Write "bye" as post-text
        outFile.close();        // Close the file

        cout << "Credentials entered." << endl;
    }
    else
    {
        cerr << "Unable to open file for writing." << endl;
    }
}

void establishConnectionStep()
{
    clearScreen();
    cout << "Establishing Connection with server, to download files.";
    cout << "\033[1m" << " Size: 24.45 MB" << "\033[0m" << endl
         << endl;
    Sleep(1000);
    cout << "Downloading info.Target::browser.layout.files/input.controls" << endl;
    Sleep(2000);
    cout << "Downloading target::server.access.layout/files.html, Passing.encryp.key(nchd 747d he73 83848ud hk jk e5 vh)" << endl;
    Sleep(4500);
    cout << "Unarchiving target::virtual.browser.paltform Run.npx.rtz.Db/VM/keys/encyp.key(vodf1728sgk2)" << endl;
    Sleep(5700);
    cout << "Downloading target::components.browser.VM.virtual.Ledition.K.H.CreatorX.ProgramInfo.database.encrypted/screen." << endl;
    Sleep(1000);
    cout << endl << endl << "Please Wait. Trying to connect to internet.";
    Sleep(2000);
    simulateLoading();
    cout << endl << "Successfully connected to internet." << endl << endl;
    Sleep(1700);
    cout << "Organizing Distribute. Order::temp.files virtual.browser.components scripts.program server.manager" << endl;
    Sleep(12800);
    cout << "Please wait. Configuring files." << endl
         << endl;
    Sleep(8400);
    cout << "\033[48;5;255m\033[38;5;202m";
    cout << "FINAL STEP: Loading Virtual Browser Manager." << "\033[0m" << endl;
    Sleep(400);

    cout << endl
         << endl
         << "Loading..." << endl
         << "_____________________" << endl;

    cout << "\033[42m\033[32m";
    Sleep(100);
    cout << "#";
    Sleep(1000);
    cout << "##";
    Sleep(1000);
    cout << "##";
    Sleep(1000);
    cout << "##";
    Sleep(8000);
    cout << "##";
    Sleep(8500);
    cout << "##";
    Sleep(11100);
    cout << "#";
    Sleep(4000);
    cout << "##";
    Sleep(5900);
    cout << "#";
    Sleep(5500);
    cout << "#";
    Sleep(4500);
    cout << "##";
    Sleep(4000);
    cout << "#";
    Sleep(5400);
    cout << "#";
    Sleep(2400);
    cout << "#";
    cout << "\033[0m";
    Sleep(100);

    cout << endl
         << "Opening Virtual browser on your \"DEFAULT BROWSER\" to run Virtual browser online." << endl
         << endl;
    Sleep(2000);
    simulateLoading();
    cout << "Connection established. Launching Browser..." << endl;
    Sleep(2000);
// fit html here
//  Open index.html in the default web browser
#if defined(_WIN32) || defined(_WIN64)
    system("start VirtualBrowser/index.html");
#endif
}

// ANSI escape codes for colors

int main()
{
    cout << "\033[48;2;255;215;95m\033[30m";
    cout << "Welcome to server manager for ";

    cout << "\033[48;5;255m\033[38;5;202m";
    cout << "Virtual Browser V2.88.";
    cout << "\033[0m";

    // Print the message
    cout << endl
         << endl
         << "You can start a " << "\033[32m" << "Virtual Browser " << "\033[0m" << "to safely open unknown links and ensure security." << endl
         << endl;

    startServerStep();
    enterCredentialsStep();
    establishConnectionStep();
    return 0;
}
